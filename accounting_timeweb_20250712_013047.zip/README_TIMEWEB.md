# Деплой на Timeweb

## Инструкция по установке:

1. Загрузите все файлы в корневую директорию сайта
2. Создайте базу данных MySQL в панели Timeweb
3. Настройте переменные окружения в панели Timeweb:
   - DB_HOST
   - DB_NAME  
   - DB_USER
   - DB_PASS
   - SECRET_KEY
   - ADMIN_PASSWORD

4. Установите зависимости:
   pip install -r requirements_timeweb.txt

5. Настройте .htaccess для работы с Python

## Структура файлов:
- app.py - основное приложение
- wsgi.py - WSGI файл
- config_timeweb.py - конфигурация для Timeweb
- requirements_timeweb.txt - зависимости
- .htaccess - настройки веб-сервера

## База данных:
- Создайте MySQL базу данных в панели Timeweb
- Импортируйте структуру из database.sql
- Настройте подключение в config_timeweb.py
