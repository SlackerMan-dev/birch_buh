# Конфигурация для Timeweb
import os

# Настройки базы данных Timeweb
DB_HOST = os.environ.get('DB_HOST', 'localhost')
DB_NAME = os.environ.get('DB_NAME', 'your_database_name')
DB_USER = os.environ.get('DB_USER', 'your_username')
DB_PASS = os.environ.get('DB_PASS', 'your_password')

# Настройки приложения
SECRET_KEY = os.environ.get('SECRET_KEY', 'your-secret-key-change-in-production')
ADMIN_PASSWORD = os.environ.get('ADMIN_PASSWORD', 'Blalala2')

# Пути к файлам
UPLOAD_FOLDER = os.path.join(os.path.dirname(__file__), 'uploads')
INSTANCE_PATH = os.path.join(os.path.dirname(__file__), 'instance')

# Создаем директории если не существуют
os.makedirs(UPLOAD_FOLDER, exist_ok=True)
os.makedirs(INSTANCE_PATH, exist_ok=True)
